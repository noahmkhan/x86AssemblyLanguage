Noah Khan
nomkhan
Fall 2021
ASCII-ricks (Astericks)

-----------
DESCRIPTION

In this lab, the user enters a height greater than 0. The program will print the shape
with decimal numbers and astericks. The shape created is a right triangle. Each line 
begins with an integer number followed by a certian amount of asteriks, with the 
exception of the first line. Multiple asteriks are seperated by tabs. If the user
inputs a number less than 1, then the program will display an error message and prompt
the user to input a valid number.

-----------
FILES

-
Lab3.asm

This file includes code that runs on MARS IDE. The code prints out a shape with a height 
given by the user.

-----------
INSTRUCTIONS

This program is intended to be run using the MIPS Assembler and Runtime Simulator (MARS). 
Enter the test case as a program argument and run using MARS.
