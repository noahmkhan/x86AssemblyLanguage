Noah Khan
nomkhan
Fall 2021
Functions and Graphics

-----------
DESCRIPTION

In this lab, the program uses functions and subroutines to store hexadecimal values into an
array of memory.

-----------
FILES

-
lab4.asm

This file includes assembly code to print colors given bitmap coordinates.
This program also utilizes funtions and subroutines to print clear the entire
bitmp  display, draw a single pixel, draw a verticle line, draw a horizontal
line and draw a crosshair. These functions/subroutines use the stack to store
memory.

-
lab4_s21_test.asm

This file utilizes lab4.asm and runs a series of tests to check if the funcitons
execute properly.

-----------
INSTRUCTIONS

This program is intended to be run using the MIPS Assembler and Runtime Simulator (MARS). Run the test codes
to test for program functionality.
